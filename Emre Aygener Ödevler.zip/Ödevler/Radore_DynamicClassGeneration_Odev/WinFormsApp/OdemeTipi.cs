﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp
{
    public class OdemeTipi
    {
        public int Id { get; set; }
        public string className { get; set; }
        public string displayName { get; set; }
    }
}
