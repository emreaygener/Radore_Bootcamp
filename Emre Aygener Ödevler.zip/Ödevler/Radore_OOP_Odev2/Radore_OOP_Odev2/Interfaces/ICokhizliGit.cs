﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Radore_OOP_Odev2.Interfaces
{
    public interface ICokhizliGit
    {
        void CokhizliGit();
    }
}
